<?php
   session_start();
   if(!$_SESSION['codusu']>0){header("location:index.php");exit;}
   require("include/fpdf/fpdf.php");
   $pdf=new FPDF();
   $pdf->addpage();
   $pdf->image("imagens/loja.png",10,10,185);
   $pdf->ln(30);
   $pdf->setfont('arial','B',12);
   $pdf->cell(185,6,"RELATORIO DE PRODUTOS EM FALTA" ,'BTLR',1,'C');
   $pdf->ln(2);
   $cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
   $res=pg_query("select *, qtdprod*valorprod as totpro from produtos WHERE qtdprod<10 AND tipoprod='Produto Customizavel' OR tipoprod='Porta Retrato' order by totpro");
   $pdf->setfont('arial','B',12);
   $pdf->cell(185,5,"DETALHES DOS PRODUTOS: $reg->tipoprod",'BTLR',1);
   $totqtd=$totval=$tottot=0;
   $pdf->setfont('arial','B',10);
   $pdf->cell(8,4,"",'');
   $pdf->cell(16,4,"CODIGO",'BTLR',0,'R');
   $pdf->cell(85,4,"DESCRICAO",'BTLR');
   $pdf->cell(26,4,"QUANTIDADE",'BTLR',0,'R');
   $pdf->cell(25,4,"VALOR",'BTLR',0,'R');
   $pdf->cell(25,4,"TOTAL",'BTLR',1,'R');
   $pdf->setfont('arial','',10);
   while($reg=pg_fetch_object($res)){
      $pdf->cell(8,4,"",'');
      $pdf->cell(16,4,"$reg->codigo",'BTLR',0,'R');
      $pdf->cell(85,4,"$reg->nomeprod",'BTLR');
      $pdf->setfont('arial','B',10);
      $pdf->SetTextColor(194,8,8);
      $pdf->cell(26,4,"$reg->qtdprod",'BTLR',0,'R');
      $pdf->setfont('arial','',10);
      $pdf->SetTextColor(1,1,1);
      $pdf->cell(25,4,"$reg->valorprod",'BTLR',0,'R');
      $pdf->cell(25,4,"$reg->totpro",'BTLR',1,'R');
      $totll+=$regpro->qtdprod;
      $totval+=$regpro->valorprod;
      $tottot+=$regpro->totpro;
    }
       
   $pdf->output();
?>