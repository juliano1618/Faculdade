<?php
     session_start();
     $cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
     $res=pg_query("select * from usuarios
                   where codusu=$_POST[codusu] and
                   senusu=md5(nomusu || '$_POST[senusu]')");
                   
     if($reg=pg_fetch_object($res)){
     	   $_SESSION[codusu]=$reg->codusu;
     	   $_SESSION[nomusu]=$reg->nomusu;
         header("location:menu.php");         
     } else {
         echo("
          <script>
            alert('Senha inválida...');
            document.location='index.php';
         </script>");   
     
     }
?>


