<?php 
 	session_start();
?>

<html>

<head>
   <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
   <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
   <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
</head>

<body>
   <table id="listarusu" class="display" width="100%" cellspacing="0">
      <thead>
         <tr><th>Código</th><th>Nome</th><th>Opções</th></tr>
      </thead>
      <tbody>
         <?php
            $cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
            $res=pg_query("select codusu,nomusu from usuarios");
            while($reg=pg_fetch_object($res)){
            	echo("<tr><td>$reg->codusu</td><td>$reg->nomusu</td><td>ALTERAR -- EXCLUIR</td></tr>");
            }
         ?>     	
      </tbody>
   </table>
   <script>
		$(document).ready(function() {
   		 $('#listarusu').DataTable( {
        		 stateSave: true
  	     	} );
   	} );
   </script>
</body>

</html>