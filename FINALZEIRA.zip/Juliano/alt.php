<?php

   	session_start();
   	if(!$_SESSION['codusu']>0){header("location:index.php");exit;}

     $cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
     
     if($_GET[codigo]) {
     		$res=pg_query("Select * From Produtos WHERE codigo=$_GET[codigo]");
     		$reg=pg_fetch_object($res);
     }elseif($_POST[codigo]){
			$res=pg_query("UPDATE produtos SET nomeprod='$_POST[nomeprod]',qtdprod='$_POST[qtdprod]',valorprod='$_POST[valorprod]',tipoprod='$_POST[tipoprod]',obsprod='$_POST[obsprod]' WHERE codigo=$_POST[codigo]");
     		if($res){
				echo("<script>alert('Alterado com sucesso');document.location='menuprod.php';</script>");   
   		}else{
				echo("<script>alert('Produto não Alterado');document.location='menuprod.php';</script>");      
  	   	}		
     }					  
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Photograph</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style>
	.container{
		background-color:black;
		width:100%;	
		border-width: 1px;
    	border-style: dotted;
	}
	
	.direita{
		text-align:right;
		margin-top:15px;
	}
	
	h3 {
		color:white;	
	}
	
	form {
		width:150px;	
	}
	
	.form{
		margin-left:45%;
	}
	
	legend{
		margin-top:50px;
		color:red;	
	}
	
	body {
		background: -webkit-gradient(linear, left top, left bottom, from(#666), to(#fff)) repeat-X;		
	}
	
</style>

<body>
<div class="container">
  <h3>Photograph</h3>
    <div class="direita">		
	 	<a href="index.php">Sair</a>
  	 </div> 	 
</div>
<div class="form">
  		<form method="POST" action="alt.php">
  			<legend>Produto</legend>
  			<input type="hidden" name="codigo" value="<?php echo $reg->codigo;?>">  			
  			Nome: <input type="text" name="nomeprod" value="<?php echo $reg->nomeprod;?>">
  			<br><br>
  			Quantidade <input type="text" name="qtdprod" value="<?php echo $reg->qtdprod;?>"> 
  			<br><br>
  			Valor: <input type="text" name="valorprod" value="<?php echo $reg->valorprod;?>">
  			<br><br>
  			Tipo: <input type="text" name="tipoprod" value="<?php echo $reg->tipoprod;?>">
  			Observação:
  			<textarea name="obsprod" rows="5" cols"25" value="<?php echo $reg->obsprod;?>"></textarea>
  			<br>
  			<input type="Submit" name="foi2" value="Alterar">
  		</form> 	
</div>
</body>
</html>
