<?php
  	  session_start();
     if(!$_SESSION['codusu']>0){header("location:index.php");exit;}

     $cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
     $res=pg_query("DELETE from produtos WHERE codigo=$_GET[codigo]");
	   if($res){
			echo("<script>alert('Excluido com sucesso');document.location='menuprod.php';</script>");   
   	}else{
			echo("<script>alert('Produto não excluido');document.location='menuprod.php';</script>");      
  	   }		
  	   
?>  	   