<?php
   session_start();
   if(!$_SESSION['codusu']>0){header("location:index.php");exit;}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Photograph</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<style>
	.container{
		background-color:black;
		width:100%;	
		border-width: 1px;
    	border-style: dotted;
	}
	
	.direita{
		text-align:right;
		margin-top:15px;
	}
	
	h3 {
		color:white;	
	}
	
	form {
		width:150px;	
	}
	
	.form{
		margin-left:45%;
	}
	
	legend{
		margin-top:50px;
		color:red;	
	}
	
	body {
		background: -webkit-gradient(linear, left top, left bottom, from(#666), to(#fff)) repeat-X;		
	}
	
</style>

<body>
<div class="container">
  <h3>Photograph</h3>
  <ul class="nav nav-pills">
 	 <li><a href="menu.php">Home</a></li>
  	 <li class="active"><a href="menuprod.php">Produtos</a></li>
    <div class="direita">		
	 	<a href="index.php">Sair</a>
  	 </div> 	 
</div>
<div class="form">
  		<form action="cadprod.php" method="POST">
  			<legend>Produto</legend>
  			Nome: <input type="text" name="nomeprod">
  			<br><br>
  			Quantidade <input type="text" name="qtdprod">
  			<br><br>
  			Valor: <input type="text" name="valorprod">
  			<br><br>
  			Tipo: <input type="text" name="tipoprod">  
  			<br><br>
  			Observação:
  			<textarea name="obsprod" rows="5" cols"25"></textarea>
  			<br><br>
  			<input type="Submit" name="foi" value="Cadastrar">
  		</form> 	
</div>
</body>
</html>