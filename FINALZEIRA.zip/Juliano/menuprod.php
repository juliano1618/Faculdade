<?php
   session_start();
   if(!$_SESSION['codusu']>0){header("location:index.php");exit;}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Photograph</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

</head>
  	<script>
		$(document).ready(function() {
   		 $('#listarusu').DataTable( {
        		 stateSave: true
  	     	} );
   	} );
   </script>
<style>
	.container{
		background-color:black;
		width:100%;	
		border-width: 1px;
    	border-style: dotted;
	}
	
	.direita{
		text-align:right;
		margin-top:15px;
	}
	
	h3 {
		color:white;	
	}
	
	th {
		text-align:center;	
	}
	
	tr {
		text-align:center;	
	}
	
</style>

<body>

<div class="container">
  <h3>Photograph</h3>
  <ul class="nav nav-pills">
  	 <li><a href="menu.php">Home</a></li>
    <li class="active"><a href="">Produtos</a></li>
    <li><a href="formcad.php">Cadastrar Produtos</a></li>
  	 <div class="direita">
  	 	<a href="menu.php">Voltar --</a>
	 	<a href="index.php">Sair</a>
  	 </div>
  </ul>	 	 
</div>
<div>
	<table id="listarusu" class="display" width="100%" cellspacing="0" align="center">
      <thead>
         <tr><th>Código</th><th>Nome</th><th>Quantidade</th><th>Valor</th><th>Tipo</th><th>Opções</th></tr>
      </thead>
      <tbody>
         <?php
            $cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
            $res=pg_query("select * from produtos");
            while($reg=pg_fetch_object($res)){
            	echo("<tr><td>$reg->codigo</td><td>$reg->nomeprod</td><td>$reg->qtdprod</td><td>$reg->valorprod</td><td>$reg->tipoprod<td><a href='alt.php?codigo=$reg->codigo'>ALTERAR</a> -- <a href='exc.php?codigo=$reg->codigo'>EXCLUIR</a></td></tr>");
            }
         ?>     	
      </tbody>
   </table>
</div>   
</body>
</html>