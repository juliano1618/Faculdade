<?php
   session_start();
   if(!$_SESSION['codusu']>0){header("location:index.php");exit;}
   require("include/fpdf/fpdf.php");
   $pdf=new FPDF();
   $pdf->addpage();
   $pdf->image("imagens/loja.png",10,10,185);
   $pdf->ln(30);
   $pdf->setfont('arial','B',12);
   $pdf->cell(185,6,"RELATORIO DE PRODUTOS",'BTLR',1,'C');
   $pdf->ln(2);  
   $cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
   $res=pg_query("select * from produtos");
   $pdf->setfont('arial','B',12);
   $pdf->cell(185,5,"Todos Os Produtos Disponiveis Em Estoque",'BTLR',1);
   $totqtd=$totval=$tottot=0;
   $pdf->setfont('Arial','B',10);
   $pdf->cell(8,4,"",'');
   $pdf->cell(16,4,"CODIGO",'BTLR',0,'R');
   $pdf->cell(86,4,"DESCRICAO",'BTLR');
   $pdf->cell(25,4,"QUANTIDADE",'BTLR',0,'R');
   $pdf->cell(25,4,"VALOR",'BTLR',0,'R');
   $pdf->cell(25,4,"TOTAL",'BTLR',1,'R');
   $pdf->setfont('arial','',10);
   $respro=pg_query("select *, qtdprod*valorprod as totpro from produtos order by totpro");
   while($regpro=pg_fetch_object($respro)){
       $pdf->cell(8,4,"",'');
       $pdf->cell(16,4,"$regpro->codigo",'BTLR',0,'R');
       $pdf->cell(86,4,"$regpro->nomeprod",'BTLR');
       $pdf->cell(25,4,"$regpro->qtdprod",'BTLR',0,'R');
       $pdf->cell(25,4,"$regpro->valorprod",'BTLR',0,'R');
       $pdf->cell(25,4,"$regpro->totpro",'BTLR',1,'R');
       $totll+=$regpro->qtdprod;
       $totval+=$regpro->valorprod;
       $tottot+=$regpro->totpro;
   	}    
   $pdf->output();
?>