<?php

   session_start();
   if(!$_SESSION['codusu']>0){header("location:index.php");exit;}
	$cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
   $res=pg_query("insert into produtos (nomeprod, qtdprod, valorprod,tipoprod, obsprod) 
   					VALUES ('$_POST[nomeprod]','$_POST[qtdprod]','$_POST[valorprod]','$_POST[tipoprod]','$_POST[obsprod]')");
   if($res){
		echo("<script>alert('Cadastrado com sucesso');document.location='menuprod.php';</script>");   
   }else{
		echo("<script>alert('Produto não cadastrado');document.location='menuprod.php';</script>");      
   }					
?>