<?php
	session_start();
	session_unset();
?>

<head>
  <title>Photograph</title>
  <meta charset="utf-8">
</head>

<style>
	
	legend{
		margin-top:50px;
		color:red;
		margin-left:38%;	
	}
	
	select {
		width:176px;	
	}
	

	
	fieldset{
		height:250px;
		margin-left:38%;
		width:300px;
		padding-top: 0.35em;
      padding-bottom: 0.625em;
      padding-left: 0.75em;
      padding-right: 0.75em;
		border: 4px;
      box-shadow: 10px 9px 50px #000;
      color:black;
      border-radius:10px;
      background-color:#DCDCDC;
	}
	
	#bt3{
		color:red;
		border-radius:5px;
		margin-top:5%;
		margin-left:40%;
		background-color:white;
		padding-top: 0.35em;
      padding-bottom: 0.625em;
      padding-left: 0.75em;
      padding-right: 0.75em;
	}
	
	img {
		width:98%;
		height:30%;
		padding-top: 0.35em;
      padding-bottom: 0.625em;
      padding-left: 0.75em;
      padding-right: 0.75em;	
	}
</style>	
<img src="imagens/loja.png">
<div class="form">
	<form method="post" action="valida.php">
	<fieldset>
	<legend>LOGIN</legend>
	<br>
 	<b>Usuário:</b> <select name="codusu">
	<?php
     $cnx=pg_connect("host=177.222.216.50 dbname=2016100175 user=2016100175 password=0175");
     $res=pg_query("select * from usuarios");
     while($reg=pg_fetch_object($res)){
         echo("<option value=$reg->codusu>$reg->nomusu</option>");    
     }
	?>
</div>	
   </select><br><br>
   <b>Senha:</b>
   <input type="password" name="senusu" size="14px">
   <br><br>
   <input type="submit" value="Logar" id="bt3">
   </fieldset>
</form>

