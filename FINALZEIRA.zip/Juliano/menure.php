<?php
	session_start();
	if(!$_SESSION['codusu']>0){header("location:index.php");exit;}
?>	
	

<html lang="en">
<head>
  <title>Photograph</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<style>
	.container{
		background-color:black;
		width:100%;	
		border-width: 1px;
    	border-style: dotted;
	}
	
	.direita{
		text-align:right;
		margin-top:15px;
	}
	
	h3 {
		color:white;	
	}
	
	img {
		width:100%;
		height:83%	
	}
</style>

<body>

<div class="container">
  <h3>Photograph</h3>
  <ul class="nav nav-pills">
    <li class="active"><a href="menu.php">Home</a></li>
    <li><a href="relpro.php">Relatorios Produtos Em Falta</a></li>
    <li><a href="relpro2.php">Relatorios Todos Os Produtos</a></li>
  	 <div class="direita">
	 	<a href="index.php">Sair</a>
  	 </div>
  </ul>	 	 
</div>
<img src="imagens/fundo.jpg"
</body>
</html>